/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginregistrationsystems2;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class LoginRegistrationSystems2 {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);
        
         //user's details
    
    System.out.println("\n---Registration---");
    
    String firstName;
    String lastName;
    String userName;
    String password;
    String cellPhoneNumber;
            
    System.out.print("Enter first name: ");
    firstName = input.next();
    
    System.out.print("Enter last name: ");
    lastName = input.next();
    
    System.out.print("Enter username: ");
    userName = input.next();
    
    
        if (userName.length() <=5 && userName.contains("_")) {
        
    }else {
            System.out.println("Username is not correctly formatted; please ensure that your username contains and underscore and is no more");
        }
    System.out.print("Enter password: ");
    password = input.next();
    
    System.out.print("Enter cellphone number: ");
    cellPhoneNumber = input.next();
              
    //cellphone number validation
    if(cellPhoneNumber.matches("^\\+?27\\d{9}$")) {
}else {
        System.out.println("cell phone number does not contain international code");
         System.out.print("\n ===Login===");
     // user's details
     
     System.out.print("Enter username: ");
     System.out.println("username must contain underscore and characters<=5 ");
     userName = input.nextLine();
     
  // Handles login and returns status message
      System.out.print("Ënter username: ");
      
     System.out.print("Enter password: ");
     String loginPassword = input.next();
      
  //cellphone number
  boolean validCell = false;
  while (!validCell) {
  System.out.print("Enter cellphone number:");
  String cellNumber = input.next();
           
     //Validates SA cell number: must be +27 followed by 9 digits
           public static boolean checkCellphoneNumber(String cellNumber) {
      return cellNumber.matches("^^\\+27\\d{9}$");
      
       
       }
     
     // Handles login and returns status message
     public static void returnLoginStatus() {
     System.out.print("Enter username: ");    
     

 }     
             
             
      
             
}
    
    


    

    